﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class Scene : MonoBehaviour
{
    public void mainMenu()
    {
        SceneManager.LoadScene("MainMenu");
    }
    public void help()
    {
        SceneManager.LoadScene("Help");
    }
    public void GamePlay()
    {
        SceneManager.LoadScene("GamePlay");
        Time.timeScale = 1;
    }
    public void exit()
    {
        Application.Quit();
    }
}
