﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Player : MonoBehaviour
{
    private AudioSource audio;
    float moveSpeed = 10;
    void Start()
    {
        audio = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    private void Update()
    {
        if (transform.position.y > 7.4f || transform.position.y < -7.4f || transform.position.x < -12.7f || transform.position.x > 12.7f)
        {
            audio.Play();
            Time.timeScale = 0;
            SceneManager.LoadScene("GameOver");
        }
    }


    private void FixedUpdate()
    {
        movement();
    }

    void movement()
    {
        Vector3 movement = new Vector3(Input.GetAxis("Horizontal"), Input.GetAxis("Vertical"), 0f);
        transform.position += movement * Time.deltaTime * moveSpeed;
    }
}
