﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawn : MonoBehaviour
{
    public GameObject enemy;
    public float spawnTime = 0.1f;
    private Vector2 screen;

    private void Start()
    {
        screen = Camera.main.ScreenToWorldPoint(new Vector3(Screen.width, Screen.height, Camera.main.transform.position.z));
        StartCoroutine(wave());
    }

    private void spawn()
    {
        GameObject E = Instantiate(enemy) as GameObject;
        E.transform.position = new Vector2(13.02f, Random.Range(-screen.y, screen.y));
    }

    IEnumerator wave()
    {
        while (true)
        {
            yield return new WaitForSeconds(spawnTime);
            spawn();
        }

    }
}
