﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Validasi : MonoBehaviour
{
    public GameObject validasi;
    public GameObject Mainmenu;

    public void Exit()
    {
        Application.Quit();
    }

    public void noQuit()
    {
        validasi.SetActive(false);
        Mainmenu.SetActive(true);
    }

    public void validasion()
    {
        validasi.SetActive(true);
        Mainmenu.SetActive(false);
    }
}
