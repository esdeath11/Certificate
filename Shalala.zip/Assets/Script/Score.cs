﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Score : MonoBehaviour
{
    public Text ScoreText;
    public static float nilai;
    float scoreIncrease;

    void Start()
    {
        nilai = 0f;
        scoreIncrease = 1f;
        
    }

    
    void Update()
    {
        ScoreText.text = "Score : " + (int)nilai;
        nilai += scoreIncrease * Time.deltaTime;
    }
}
